/* Zepto Quick-Commerce MVP – Single JS bundle (ES6) */
(() => {
  /* ========= DATA & STATE ========= */
  const initialProducts = [
    { id: 1, name: 'Toned Milk 500ml', category: 'Dairy', price: 28, stock: 30, img: 'https://via.placeholder.com/150' },
    { id: 2, name: 'Brown Bread Loaf', category: 'Bakery', price: 45, stock: 25, img: 'https://via.placeholder.com/150' },
    { id: 3, name: 'Tomato 1kg', category: 'Fresh', price: 34, stock: 50, img: 'https://via.placeholder.com/150' },
    { id: 4, name: 'Basmati Rice 1kg', category: 'Staples', price: 110, stock: 40, img: 'https://via.placeholder.com/150' },
    { id: 5, name: 'Instant Coffee 100g', category: 'Beverages', price: 145, stock: 20, img: 'https://via.placeholder.com/150' },
    { id: 6, name: 'Chicken Breast 500g', category: 'Meat', price: 210, stock: 15, img: 'https://via.placeholder.com/150' },
    { id: 7, name: 'Shampoo 180ml', category: 'Personal Care', price: 95, stock: 35, img: 'https://via.placeholder.com/150' },
    { id: 8, name: 'Dishwash Liquid 500ml', category: 'Cleaning', price: 70, stock: 30, img: 'https://via.placeholder.com/150' },
    { id: 9, name: 'Chocolate Bar 50g', category: 'Snacks', price: 40, stock: 60, img: 'https://via.placeholder.com/150' },
    { id: 10, name: 'LED Bulb 9W', category: 'Electronics', price: 120, stock: 22, img: 'https://via.placeholder.com/150' }
  ];

  const state = {
    products: JSON.parse(JSON.stringify(initialProducts)), // deep copy
    cart: [],
    orders: [],
    user: null,
  };

  window.appState = state; // Expose for debugging

  /* ========= UTILITIES ========= */
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const formatPrice = (p) => `₹${p.toFixed(2)}`;

  const findProduct = (id) => state.products.find((p) => p.id === id);

  /* ========= CART HELPERS ========= */
  function addToCart(productId, qty = 1) {
    const line = state.cart.find((l) => l.productId === productId);
    if (line) {
      line.qty = Math.min(line.qty + qty, findProduct(productId).stock);
    } else {
      state.cart.push({ productId, qty: Math.min(qty, findProduct(productId).stock) });
    }
    updateCartUI();
  }

  function updateCartQty(productId, qty) {
    const line = state.cart.find((l) => l.productId === productId);
    if (!line) return;
    if (qty <= 0) {
      state.cart = state.cart.filter((l) => l.productId !== productId);
    } else {
      line.qty = Math.min(qty, findProduct(productId).stock);
    }
    updateCartUI();
  }

  function cartCount() {
    return state.cart.reduce((n, l) => n + l.qty, 0);
  }
  function cartSubtotal() {
    return state.cart.reduce((sum, l) => sum + l.qty * findProduct(l.productId).price, 0);
  }

  /* ========= ROUTER ========= */
  const routes = {};

  function addRoute(path, action) {
    routes[path] = action;
  }

  function parseHash() {
    const hash = location.hash.slice(1) || '/login';
    const [path, ...rest] = hash.split('/').filter(Boolean);
    return { path: '/' + path, params: rest };
  }

  function handleRoute() {
    const { path, params } = parseHash();

    if (!state.user && path !== '/login') {
      location.hash = '/login';
      return;
    }

    const action = routes[path] || routes['/404'];
    if (action) action(params);
  }

  window.addEventListener('hashchange', handleRoute);

  /* ========= HEADER CONTROLS ========= */
  const cartBtn = $('#cartBtn');
  const cartCountEl = $('#cartCount');
  const searchInput = $('#globalSearch');
  const header = $('#siteHeader');
  const cartDrawer = $('#cartDrawer');

  cartBtn.addEventListener('click', () => {
    renderCartDrawer();
    cartDrawer.classList.add('open');
    cartDrawer.setAttribute('aria-hidden', 'false');
  });
  $('#closeCart').addEventListener('click', () => {
    cartDrawer.classList.remove('open');
    cartDrawer.setAttribute('aria-hidden', 'true');
  });

  function updateCartUI() {
    const count = cartCount();
    cartCountEl.textContent = count;
  }

  function setHeaderAuthenticated(isAuth) {
    if (isAuth) {
      cartBtn.classList.remove('hidden');
      searchInput.classList.remove('hidden');
    } else {
      cartBtn.classList.add('hidden');
      searchInput.classList.add('hidden');
    }
  }

  /* ========= VIEWS ========= */
  const app = $('#app');

  /* --- LOGIN --- */
  function LoginView() {
    setHeaderAuthenticated(false);
    app.innerHTML = `
      <div class="flex flex-col items-center gap-16" style="max-width:320px;margin:0 auto;">
        <h2>Login</h2>
        <form id="loginForm" class="flex flex-col gap-16 w-full">
          <div class="form-group">
            <label class="form-label" for="email">Email</label>
            <input required type="email" id="email" class="form-control" placeholder="you@example.com" />
          </div>
          <button class="btn btn--primary" type="submit">Continue</button>
        </form>
      </div>
    `;

    $('#loginForm').addEventListener('submit', (e) => {
      e.preventDefault();
      state.user = { email: $('#email').value };
      setHeaderAuthenticated(true);
      location.hash = '/home';
    });
  }

  /* --- HOME / CATALOG --- */
  function HomeView() {
    setHeaderAuthenticated(true);
    const categories = [...new Set(state.products.map((p) => p.category))];

    // Render skeleton first
    app.innerHTML = `
      <div class="flex gap-16 mb-16 flex-wrap" id="categoryFilters"></div>
      <div id="productGrid" class="product-grid"></div>
    `;

    const filtersEl = $('#categoryFilters');
    categories.forEach((cat) => {
      const btn = document.createElement('button');
      btn.textContent = cat;
      btn.className = 'btn btn--secondary btn--sm';
      btn.addEventListener('click', () => renderProducts(cat, searchInput.value.trim()));
      filtersEl.appendChild(btn);
    });

    searchInput.value = '';
    searchInput.oninput = () => renderProducts(undefined, searchInput.value.trim());

    renderProducts();
  }

  function renderProducts(category, searchTerm) {
    const grid = $('#productGrid');
    let list = [...state.products];
    if (category) list = list.filter((p) => p.category === category);
    if (searchTerm) list = list.filter((p) => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

    if (list.length === 0) {
      grid.innerHTML = '<p>No products match.</p>';
      return;
    }

    grid.innerHTML = '';
    list.forEach((p) => {
      const card = document.createElement('div');
      card.className = 'product-card';
      card.innerHTML = `
        <img src="${p.img}" alt="${p.name}" />
        <div class="name">${p.name}</div>
        <div class="price">${formatPrice(p.price)}</div>
        <button class="btn btn--primary btn--sm addBtn">Add</button>
      `;
      card.querySelector('img').addEventListener('click', () => showProductModal(p));
      card.querySelector('.name').addEventListener('click', () => showProductModal(p));
      card.querySelector('.addBtn').addEventListener('click', () => addToCart(p.id, 1));
      grid.appendChild(card);
    });
  }

  /* --- PRODUCT MODAL --- */
  const productModal = $('#productModal');
  const modalOverlay = $('#modalOverlay');
  const modalContent = $('#modalContent');

  modalOverlay.addEventListener('click', () => closeProductModal());

  function showProductModal(prod) {
    modalContent.innerHTML = `
      <div class="flex flex-col gap-16">
        <img src="${prod.img}" alt="${prod.name}" style="width:100%;height:200px;object-fit:cover;border-radius:var(--radius-base);" />
        <h3>${prod.name}</h3>
        <p>${formatPrice(prod.price)}</p>
        <p style="color:var(--color-text-secondary);">Freshly sourced and delivered within minutes.</p>
        <div class="quantity-stepper">
          <button class="qty-btn" id="decQty">-</button>
          <span id="qtyVal">1</span>
          <button class="qty-btn" id="incQty">+</button>
        </div>
        <button class="btn btn--primary" id="addToCartModal">Add to Cart</button>
      </div>
    `;
    let qty = 1;
    const qtyVal = $('#qtyVal', modalContent);
    $('#decQty', modalContent).onclick = () => {
      qty = Math.max(1, qty - 1);
      qtyVal.textContent = qty;
    };
    $('#incQty', modalContent).onclick = () => {
      qty = Math.min(prod.stock, qty + 1);
      qtyVal.textContent = qty;
    };
    $('#addToCartModal', modalContent).onclick = () => {
      addToCart(prod.id, qty);
      closeProductModal();
    };

    productModal.classList.remove('hidden');
  }

  function closeProductModal() {
    productModal.classList.add('hidden');
  }

  /* --- CART DRAWER --- */
  function renderCartDrawer() {
    const body = $('#cartItems');
    body.innerHTML = '';
    if (state.cart.length === 0) {
      body.innerHTML = '<p>Your cart is empty.</p>';
    } else {
      state.cart.forEach((line) => {
        const prod = findProduct(line.productId);
        const row = document.createElement('div');
        row.className = 'cart-item';
        row.innerHTML = `
          <div>
            <div>${prod.name}</div>
            <div style="color:var(--color-text-secondary);font-size:12px;">${formatPrice(prod.price)}</div>
          </div>
          <div class="quantity-stepper">
            <button class="qty-btn dec">-</button>
            <span class="qval">${line.qty}</span>
            <button class="qty-btn inc">+</button>
          </div>
        `;
        row.querySelector('.dec').onclick = () => {
          updateCartQty(prod.id, line.qty - 1);
          renderCartDrawer();
        };
        row.querySelector('.inc').onclick = () => {
          updateCartQty(prod.id, line.qty + 1);
          renderCartDrawer();
        };
        body.appendChild(row);
      });
    }

    $('#cartSubtotal').textContent = formatPrice(cartSubtotal());
  }

  $('#checkoutBtn').addEventListener('click', () => {
    if (state.cart.length === 0) return;
    cartDrawer.classList.remove('open');
    location.hash = '/checkout';
  });

  /* --- CHECKOUT --- */
  function CheckoutView() {
    if (state.cart.length === 0) {
      location.hash = '/home';
      return;
    }

    app.innerHTML = `
      <h2>Checkout</h2>
      <form id="checkoutForm" class="flex flex-col gap-16">
        <div class="form-group">
          <label class="form-label" for="street">Street</label>
          <input required id="street" class="form-control" placeholder="123 MG Road" />
        </div>
        <div class="form-group">
          <label class="form-label" for="city">City</label>
          <input required id="city" class="form-control" placeholder="Mumbai" />
        </div>
        <div class="form-group">
          <label class="form-label" for="pin">Pincode</label>
          <input required id="pin" class="form-control" pattern="\\d{6}" placeholder="400001" />
        </div>
        <div class="form-group">
          <span class="form-label">Payment Method</span>
          <label><input type="radio" name="pay" value="UPI" checked /> UPI</label><br/>
          <label><input type="radio" name="pay" value="Card" /> Card</label><br/>
          <label><input type="radio" name="pay" value="COD" /> Cash on Delivery</label>
        </div>
        <button class="btn btn--primary" type="submit">Place Order</button>
      </form>
    `;

    $('#checkoutForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const orderId = Date.now();
      const order = {
        id: orderId,
        items: JSON.parse(JSON.stringify(state.cart)),
        total: cartSubtotal(),
        status: 'preparing',
        eta: Date.now() + 10 * 60 * 1000, // 10 minutes from now
      };

      // Reduce stock
      state.cart.forEach((l) => {
        const prod = findProduct(l.productId);
        prod.stock = Math.max(0, prod.stock - l.qty);
      });

      state.orders.push(order);
      state.cart = [];
      updateCartUI();
      location.hash = `/track/${orderId}`;
    });
  }

  /* --- ORDER TRACKING --- */
  const activeTimers = new Map(); // orderId -> intervalID

  function TrackView([orderIdStr]) {
    const orderId = Number(orderIdStr);
    const order = state.orders.find((o) => o.id === orderId);
    if (!order) {
      app.innerHTML = '<p>Order not found.</p>';
      return;
    }

    app.innerHTML = `
      <h2>Order Tracking</h2>
      <div class="map-box" id="mapBox">
        <span class="map-start"></span>
        <span class="map-end"></span>
        <span class="map-dot" id="riderDot" style="left:16px;"></span>
      </div>
      <div class="progress-bar mb-8"><div id="progressFill" class="progress-bar__fill"></div></div>
      <p id="etaText"></p>
    `;

    const etaText = $('#etaText');
    const progressFill = $('#progressFill');
    const riderDot = $('#riderDot');
    const mapBox = $('#mapBox');
    const mapWidth = mapBox.clientWidth - 32; // minus left & right padding of markers

    function update() {
      const now = Date.now();
      const remainingMs = Math.max(0, order.eta - now);
      const elapsed = 10 * 60 * 1000 - remainingMs;
      const progress = Math.min(100, (elapsed / (10 * 60 * 1000)) * 100);

      progressFill.style.width = `${progress}%`;
      riderDot.style.left = `${16 + (progress / 100) * mapWidth}px`;

      const mins = Math.floor(remainingMs / 60000);
      const secs = Math.floor((remainingMs % 60000) / 1000);
      etaText.textContent = remainingMs > 0 ? `Arriving in ${mins}m ${secs}s` : 'Delivered';

      if (remainingMs <= 0) {
        clearInterval(activeTimers.get(orderId));
        activeTimers.delete(orderId);
        order.status = 'delivered';
      }
    }

    // Start interval (prevent duplicates)
    if (activeTimers.has(orderId)) {
      clearInterval(activeTimers.get(orderId));
    }
    update();
    const intervalId = setInterval(update, 1000);
    activeTimers.set(orderId, intervalId);
  }

  /* --- ADMIN --- */
  function AdminView() {
    app.innerHTML = `
      <h2>Dark Store Admin</h2>
      <table class="table" id="adminTable">
        <thead><tr><th>Name</th><th>Category</th><th>Price</th><th>Stock</th></tr></thead>
        <tbody></tbody>
      </table>
      <button id="saveStock" class="btn btn--primary mt-8">Save</button>
    `;

    const tbody = $('#adminTable tbody');
    state.products.forEach((p) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${p.name}</td>
        <td>${p.category}</td>
        <td>${formatPrice(p.price)}</td>
        <td><input type="number" min="0" value="${p.stock}" data-id="${p.id}" style="width:80px;" /></td>
      `;
      tbody.appendChild(tr);
    });

    $('#saveStock').addEventListener('click', () => {
      $$('input[type="number"][data-id]').forEach((inp) => {
        const prod = findProduct(Number(inp.dataset.id));
        prod.stock = Math.max(0, Number(inp.value));
      });
      alert('Stock updated!');
      location.hash = '/home';
    });
  }

  /* --- 404 --- */
  function NotFound() {
    app.innerHTML = '<p>Not found.</p>';
  }

  /* ========= REGISTER ROUTES ========= */
  addRoute('/login', LoginView);
  addRoute('/home', HomeView);
  addRoute('/checkout', CheckoutView);
  addRoute('/track', () => location.hash = '/home'); // generic, real handled by /track/:id
  addRoute('/admin', AdminView);
  addRoute('/404', NotFound);

  // Special dynamic route for track/id
  routes['/track'] = (params) => TrackView(params);

  /* ========= INITIALISE ========= */
  document.addEventListener('DOMContentLoaded', () => {
    updateCartUI();
    handleRoute();
  });
})();
